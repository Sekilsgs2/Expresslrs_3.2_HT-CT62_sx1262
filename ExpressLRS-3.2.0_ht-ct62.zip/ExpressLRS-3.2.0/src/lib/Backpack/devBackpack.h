#pragma once

#include "device.h"

void checkBackpackUpdate();

extern device_t Backpack_device;

#ifndef UNIT_TEST
#include <iostream>

using namespace std;

int main()
{
	cout << "Doing nothing just keep build all happy!" << endl;
	return 0;
}
#endif

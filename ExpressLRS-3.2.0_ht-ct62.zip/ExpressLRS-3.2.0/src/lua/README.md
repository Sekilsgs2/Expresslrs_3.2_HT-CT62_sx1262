
# Which file do I need?
* For transmitters on master, ExpressLRS 2.x, or 3.0 -> elrsV3.lua
* For transmitters on 1.x -> ELRS.lua

### Downloading from Github:
Click the file link above, find the "Raw" button near the top of that page. Right-click, Save link as.., copy the .lua file into the /SCRIPTS/TOOLS directory of the SD card on your handset.

### Downloading from Configurator:
Use the button shown in the image below to download the .lua script into the /SCRIPTS/TOOLS directory of the SD card on your handset.
![downloadlua](https://user-images.githubusercontent.com/68074253/129203116-c1234719-3e8c-4cbf-a391-b7fb8dc0262d.png)
